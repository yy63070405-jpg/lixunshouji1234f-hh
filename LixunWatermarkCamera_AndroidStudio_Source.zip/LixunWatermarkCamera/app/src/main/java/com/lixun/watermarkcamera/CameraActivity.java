package com.lixun.watermarkcamera;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CameraActivity extends AppCompatActivity {
    TextView timeText, locationText, workText;
    ImageView photoPreview;
    ActivityResultLauncher<Intent> cameraLauncher;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_camera);
        timeText=findViewById(R.id.timeText); locationText=findViewById(R.id.locationText);
        workText=findViewById(R.id.workText); photoPreview=findViewById(R.id.photoPreview);
        updateWatermark();
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION},10);

        cameraLauncher=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if(r.getResultCode()==RESULT_OK && r.getData()!=null && r.getData().getExtras()!=null) {
                photoPreview.setImageBitmap((android.graphics.Bitmap)r.getData().getExtras().get("data"));
                updateWatermark();
            }
        });
        findViewById(R.id.captureBtn).setOnClickListener(v -> cameraLauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)));
        findViewById(R.id.templateBtn).setOnClickListener(v -> startActivity(new Intent(this,TemplateActivity.class)));
        findViewById(R.id.settingsBtn).setOnClickListener(v -> startActivity(new Intent(this,SettingsActivity.class)));
    }
    void updateWatermark(){
        String now=new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss EEEE", Locale.CHINA).format(new Date());
        timeText.setText(now);
        String company=getSharedPreferences("cfg",0).getString("company","立讯项目");
        String work=getSharedPreferences("cfg",0).getString("work","现场拍照");
        workText.setText("🏢 "+company+"\n📝 工作记录："+work);
        locationText.setText("📍 当前定位（开启定位后自动更新）");
    }
    @Override protected void onResume(){super.onResume(); if(timeText!=null) updateWatermark();}
}
