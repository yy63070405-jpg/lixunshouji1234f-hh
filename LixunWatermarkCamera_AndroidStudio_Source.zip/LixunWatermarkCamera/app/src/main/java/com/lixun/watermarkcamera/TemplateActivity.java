package com.lixun.watermarkcamera;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
public class TemplateActivity extends AppCompatActivity{
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_templates);
  set("work","工作打卡");set("engineering","工程记录");set("life","生活记录");set("simple","时间地点");
 }
 void set(String id,String v){findViewById(getResources().getIdentifier(id,"id",getPackageName())).setOnClickListener(x->{getSharedPreferences("cfg",0).edit().putString("template",v).apply();Toast.makeText(this,"已选择："+v,Toast.LENGTH_SHORT).show();finish();});}
}
