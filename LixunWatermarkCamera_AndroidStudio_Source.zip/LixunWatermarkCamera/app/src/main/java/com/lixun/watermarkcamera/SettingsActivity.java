package com.lixun.watermarkcamera;
import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
public class SettingsActivity extends AppCompatActivity{
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_settings);
  EditText c=findViewById(R.id.company),w=findViewById(R.id.workContent);
  c.setText(getSharedPreferences("cfg",0).getString("company","立讯项目")); w.setText(getSharedPreferences("cfg",0).getString("work","现场拍照"));
  findViewById(R.id.save).setOnClickListener(v->{getSharedPreferences("cfg",0).edit().putString("company",c.getText().toString()).putString("work",w.getText().toString()).apply();Toast.makeText(this,"设置已保存",Toast.LENGTH_SHORT).show();finish();});
 }
}
